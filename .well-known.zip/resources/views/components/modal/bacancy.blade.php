<div>
    <!-- No surplus words or unnecessary actions. - Marcus Aurelius -->
</div>