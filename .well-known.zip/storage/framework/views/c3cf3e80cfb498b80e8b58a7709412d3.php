<h2>New Query Received</h2>

<p><strong>Name:</strong> <?php echo e($query['name']); ?></p>
<p><strong>Email:</strong> <?php echo e($query['email']); ?></p>
<p><strong>Phone:</strong> <?php echo e($query['phone']); ?></p>
<p><strong>Query:</strong> <?php echo e($query['project_brief']); ?></p>
<?php /**PATH C:\xampp\htdocs\serverfile\resources\views/emails/query.blade.php ENDPATH**/ ?>