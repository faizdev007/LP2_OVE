<div>
    
    <div class="mb-4">
        <input type="text" wire:model.debounce.500ms="search" placeholder="Search landing pages..." class="p-2 w-full md:w-1/3 border rounded shadow" />
    </div>

    <div class="border p-2 rounded-lg bg-gray-50 dark:bg-gray-900">
        <!--[if BLOCK]><![endif]--><?php if($landing_pages->isEmpty()): ?>
            <p class="text-gray-500 dark:text-gray-400 text-center"><?php echo e(__('No landing pages found.')); ?></p>
        <?php else: ?>
            <div class="overflow-x-auto bg-white dark:bg-gray-800 rounded-lg shadow">
                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                    <thead class="bg-black text-white dark:bg-gray-700">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider cursor-pointer" wire:click="sortBy('page_name')">
                                Name
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider cursor-pointer" wire:click="sortBy('lp_theme')">
                                Template
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider cursor-pointer" wire:click="sortBy('lp_url')">
                                URL
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider cursor-pointer" wire:click="sortBy('created_at')">
                                Created
                            </th>
                            <th class="px-6 py-3 text-left text-xs font-medium uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $landing_pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700 transition">
                                <td class="px-6 py-4 capitalize whitespace-nowrap text-sm font-semibold text-gray-900 dark:text-white">
                                    <?php echo e($page->page_name); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-600 dark:text-gray-400">
                                    <?php echo e($page->lp_theme); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-blue-500 truncate max-w-[200px]">
                                    <a target="_blank" href="<?php echo e(route('showlandingpage', $page->lp_url)); ?>"> <?php echo e($page->lp_url); ?></a>
                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                                    <?php echo e($page->created_at->format('M d, Y')); ?>

                                </td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm space-x-2">
                                    <a href="<?php echo e(route('create_lp_content', $page->lp_url)); ?>" class="px-3 py-1 bg-blue-500 text-white rounded hover:bg-blue-600">
                                        <?php echo e(__('Edit')); ?>

                                    </a>
                                    <form action="<?php echo e(route('delete_lp_content', $page->lp_url)); ?>" method="POST" class="inline" onsubmit="return confirm('<?php echo e(__(`Are you sure you want to delete this landing page?`)); ?>');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="px-3 py-1 bg-red-500 cursor-pointer text-white rounded hover:bg-red-600">
                                            <?php echo e(__('Delete')); ?>

                                        </button>
                                    </form> 
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
            </div>

            
            <!--[if BLOCK]><![endif]--><?php if($landing_pages->hasPages()): ?>
                <div class="mt-4">
                    <?php echo e($landing_pages->links()); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\serverfile\resources\views/livewire/landing-pages-table.blade.php ENDPATH**/ ?>