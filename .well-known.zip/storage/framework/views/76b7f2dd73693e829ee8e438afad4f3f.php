
<div class="bg-[#EAEAEA]" section="hero-section">
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2">Hero Section</legend>
                <p class="text-gray-600 ">Customize the hero section of your Bacancy landing page.</p>
                <form wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl mx-auto dark:border-neutral-700">
                    <div class="md:flex mb-3">
                        <input wire:model="hero_title_one" type="text"
                                class="bg-white md:text-md rounded-e-none xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2  border-bacancy-primary rounded-md w-[50%]"
                                placeholder="Title Black" />
                        <input wire:model="hero_title_two" type="text"
                                class="bg-white text-bacancy-primary md:text-md xl:text-xl rounded-e-none rounded-s-none sm:text-sm text-xs border xl:p-6 md:p-4 p-2  border-bacancy-primary rounded-md w-[50%]"
                                placeholder="Title Blue" />
                        <input wire:model="hero_title_three" type="text"
                                class="bg-white md:text-md xl:text-xl sm:text-sm text-xs rounded-s-none text-black border xl:p-6 md:p-4 p-2  border-bacancy-primary rounded-md w-[50%]"
                                placeholder="Title Black" />
                    </div>
                    
                    <textarea wire:model="hero_subtitle" rows="4" type="text"
                        class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 border-bacancy-primary rounded-md w-full"
                        placeholder="SubTitle" ></textarea>
    
                    <fieldset class="mb-4 border-2 border-black p-4" x-data="{ lists: <?php if ((object) ('hero_lists') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('hero_lists'->value()); ?>')<?php echo e('hero_lists'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('hero_lists'); ?>')<?php endif; ?> }">
                        <legend class="text-gray-600  font-bold">Your list items goes here!</legend>
                        <ul class="grid xl:text-xl md:text-xs text-sm list-disc list-inside">
                            <template x-for="(title, index) in lists" :key="index">
                                <li class="text-gray-900  flex gap-2 mb-4 items-center">
                                    <input 
                                        x-model="lists[index]"
                                        type="text"
                                        class="bg-white md:text-md xl:text-xl sm:text-sm text-xs text-black border p-2 border-bacancy-primary rounded-md w-full"
                                        placeholder="list item"
                                        x-bind:placeholder="'List Item ' + (index + 1)"
                                    />
                                    <button type="button" @click="lists.splice(index, 1)" class="border h-full bg-red-500 text-white text-xl px-2 border-red-500 rounded-md">×</button>
                                </li>
                            </template>
                        </ul>
                        <button type="button" @click="lists.push('')" class="px-4 py-2 bg-green-600 text-white rounded-md">Add More</button>
                    </fieldset>
                    <div class="md:flex mb-3 p-2 bg-bacancy-primary rounded-full w-max px-8">
                        <input wire:model="btntext" type="text"
                                class="bg-white md:text-md w-max bg-white xl:text-xl sm:text-sm text-xs text-black border p-0 px-2  border-bacancy-primary rounded-md w-full"
                                placeholder="Button Text" />
                    </div>
                    <fieldset class="relative flex border-2 rounded border-black p-2">
                        <legend class="text-gray-600 font-bold">Image Over Text Fields!</legend>
                        <!-- Replace 'Text goes here' with input fields -->
                         <div class="">
                            <input wire:model="box1" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 text-center border-bacancy-primary rounded-md md:rounded-e-none"
                                placeholder="Enter value 1" />
                            <input wire:model="boxtextone" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 text-center border-bacancy-primary rounded-md md:rounded-e-none"
                                placeholder="box Title" />
                         </div>
                         <div class="">
                            <input wire:model="box2" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black xl:p-6 md:p-4 p-2 border text-center border-bacancy-primary rounded-md md:rounded-s-none md:rounded-e-none"
                                placeholder="Enter value 2" />
                            <input wire:model="boxtexttwo" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 text-center border-bacancy-primary rounded-md md:rounded-s-none md:rounded-e-none"
                                placeholder="box Title" />
                         </div>
                         <div class="">
                            <input wire:model="box3" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 text-center p-2 border-bacancy-primary rounded-md md:rounded-s-none"
                                placeholder="Enter value 3" />
                            <input wire:model="boxtextthree" type="text"
                                class="bg-white flex-1 w-full md:text-md xl:text-xl sm:text-sm text-xs text-black border xl:p-6 md:p-4 p-2 text-center border-bacancy-primary rounded-md md:rounded-s-none"
                                placeholder="box Title" />
                         </div>                        
                    </fieldset>
                    <!-- Save Button -->
                    <div class="absolute -top-10 px-2 end-0 flex justify-center">
                        <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 cursor-pointer bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                            <span wire:loading wire:target="save">saving...</span>
                            <span wire:loading.remove wire:target="save">Save</span>
                        </button>
                    </div>
                </form>
            </fieldset>
        </div>
    <?php else: ?>
        <div class="relative py-2 pb-6 flex-1 overflow-hidden mx-auto md:px-4 dark:border-neutral-700">
            <div class="md:grid lg:grid-cols-3 md:grid-cols-2 items-center justify-center">
                <div class="flex-1 grid lg:col-span-2 xl:gap-6 md:py-0 py-3 gap-2 xl:gap-4 2xl:gap-6 px-6">
                    <h1 class="text-3xl xl:text-[2.6rem] 2xl:text-[3.5rem] font-extrabold text-gray-900 "><?php echo e($hero_title_one); ?> <span class="text-bacancy-primary"><?php echo e($hero_title_two); ?></span> <?php echo e($hero_title_three); ?></h1>
                    <p class="mt-2 text-black xl:text-xl 2xl:text-[1.8rem] md:text-sm  font-bold mb-3"><?php echo e($hero_subtitle); ?></p>
                    <div class="">
                        <ul class="flex flex-col justify-center gap-2 xl:gap-4 xl:text-xl 2xl:gap-5 2xl:text-3xl md:text-xs text-sm list-disc list-inside">
                            <?php
                                $list = $hero_lists;
                            ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="text-gray-900 flex gap-2">
                                    <span class="text-bacancy-primary">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" class="xl:size-9 2xl:size-10 size-6">
                                            <path fill-rule="evenodd" d="M10 18a8 8 0 1 0 0-16 8 8 0 0 0 0 16Zm3.857-9.809a.75.75 0 0 0-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 1 0-1.06 1.061l2.5 2.5a.75.75 0 0 0 1.137-.089l4-5.5Z" clip-rule="evenodd" />
                                        </svg>
                                    </span>
                                    <?php echo e($item); ?>

                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </ul>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => 'book-a-call']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-a-call']); ?>
                        <?php if (isset($component)) { $__componentOriginale9eefe50b390207aad69b8e237e3dc7d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d = $attributes; } ?>
<?php $component = App\View\Components\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ActionButton::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'book-a-call\')','title' => ''.e($btntext).'','class' => '!text-white w-max !bg-bacancy-primary hover:!bg-[#1D4ED8] 2xl:text-[1.5rem] focus:!ring-[#1D4ED8]']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $attributes = $__attributesOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__attributesOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d)): ?>
<?php $component = $__componentOriginale9eefe50b390207aad69b8e237e3dc7d; ?>
<?php unset($__componentOriginale9eefe50b390207aad69b8e237e3dc7d); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
                </div>
                <div class="flex-1 relative aspect-[1/1] flex items-center justify-center">
                    <div class="rounded-full relative overflow-hidden m-2 2xl:m-18 border-black flex items-center justify-center">
                        <div class="absolute bg-bacancy-lightblue z-10 w-full h-full"></div>
                        <div class="absolute rounded-full w-4/5 h-4/5 m-4 justify-center items-center bg-bacancy-lightblue z-10"></div>
                        <img loading="eager" fetchpriority="high" decoding="async" src="<?php echo e(asset('assets/bacancy/hero_section_person.webp')); ?>" alt="<?php echo e(config('app.name')); ?>" class="relative z-20" />
                    </div>
                    <div class="absolute rounded-full w-full h-full z-30 p-2">
                        <div class="relative w-full h-full">
                            <div class="bg-white absolute w-[30%] top-[20%] xl:text-3xl text-xl font-bold text-center text-black border p-2 border-bacancy-primary rounded-md"><?php echo e($box1); ?>

                                <div class="text-bacancy-primary font-bold lg:text-lg text-[13px] text-wrap"><?php echo e($boxtextone); ?></div>
                            </div>
                            <div class="bg-white absolute w-[30%] top-[26%] xl:text-3xl text-xl font-bold text-center end-0 text-black p-2 border border-bacancy-primary rounded-md"><?php echo e($box2); ?>

                                <div class="text-bacancy-primary font-bold lg:text-lg text-[13px]"><?php echo e($boxtexttwo); ?></div>
                            </div>
                            <div class="bg-white absolute w-[30%] bottom-[20%] end-[10%] xl:text-3xl text-xl text-center font-bold text-black border p-2 border-bacancy-primary rounded-md"><?php echo e($box3); ?>

                                <div class="text-bacancy-primary font-bold lg:text-lg text-[13px]"><?php echo e($boxtextthree); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH C:\xampp\htdocs\serverfile\resources\views/livewire/bacancypage/herosection.blade.php ENDPATH**/ ?>