<div class="py-6 border-b border-white bg-sv-gradient text-white herobg">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
    <fieldset class="container relative text-white max-w-6xl p-4 my-20 rounded mx-auto border-2 border-white">
        <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
        <legend class="text-xl font-bold text-white  markque px-2">Hero Section</legend>
        <p>Customize the hero section of your SiliconValley landing page.</p>
        <form wire:submit.prevent="save" class="mt-2 flex-1 overflow-hidden max-w-7xl mx-auto dark:border-neutral-700">
            <div class="flex flex-col gap-2 mb-4">
                <label for="hero_subtitle" class="text-sm font-medium">Hero SubTitle</label>
                <?php if (isset($component)) { $__componentOriginal7c4cb1a0e99e51d7788902376025d47b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b = $attributes; } ?>
<?php $component = App\View\Components\SimpleTextEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SimpleTextEditor::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'hero_subtitle','name' => 'hero_subtitle','content' => ''.$hero_subtitle.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $attributes = $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $component = $__componentOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
            </div>

            <div class="flex flex-col gap-2 mb-4">
                <label for="hero_title" class="text-sm font-medium">Hero Title</label>
                <?php if (isset($component)) { $__componentOriginal7c4cb1a0e99e51d7788902376025d47b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b = $attributes; } ?>
<?php $component = App\View\Components\SimpleTextEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SimpleTextEditor::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'hero_title','name' => 'hero_title','content' => ''.$hero_title.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $attributes = $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $component = $__componentOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
            </div>

            <div class="flex flex-col gap-2 mb-4">
                <label for="hero_shorttext" class="text-sm font-medium">Hero SortText</label>
                <?php if (isset($component)) { $__componentOriginal7c4cb1a0e99e51d7788902376025d47b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b = $attributes; } ?>
<?php $component = App\View\Components\SimpleTextEditor::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('simple-text-editor'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SimpleTextEditor::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'hero_shorttext','name' => 'hero_shorttext','content' => ''.$hero_shorttext.'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $attributes = $__attributesOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__attributesOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b)): ?>
<?php $component = $__componentOriginal7c4cb1a0e99e51d7788902376025d47b; ?>
<?php unset($__componentOriginal7c4cb1a0e99e51d7788902376025d47b); ?>
<?php endif; ?>
            </div>
    
            <div class="flex flex-col gap-2 mb-4">
                <label for="buttonText" class="text-sm font-medium">Hero ButtonText</label>
                <input type="text"
                    class="px-3 py-2 border w-max rounded-full bg-sv-secondary border-gray-300 text-center focus:outline-none focus:ring-2 focus:ring-bacancy-primary"
                    placeholder="Enter hero subtitle"
                    wire:model="buttonText"
                ></input>
            </div>
            <fieldset class="container relative text-white max-w-6xl p-4 rounded mx-auto border-2 border-white">
                <legend class="text-xl font-bold text-white  markque px-2">Hero Profile Section</legend>
                <div class="md:flex gap-4">
                    <div class="flex aspect-[1.3/2] h-68 flex-col gap-2 mb-4">
                        <label class="text-sm font-medium">Hero Profile Image
                            <!--[if BLOCK]><![endif]--><?php if(isset($heroPortfolio['image']) && is_object($heroPortfolio['image'])): ?>
                                <img src="<?php echo e($heroPortfolio['image']->temporaryUrl()); ?>" class="w-full object-cover rounded border shadow-md" />
                            <?php elseif($heroPortfolio['image'] && !is_object($heroPortfolio['image'])): ?>
                                <img src="<?php echo e(asset($heroPortfolio['image'])); ?>" class="w-full object-cover rounded border shadow-md" />
                            <?php else: ?>
                                <div class="h-12 w-full flex items-center justify-center border shadow-md text-sm text-white p-2">
                                    Upload Logo
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <input type="file" wire:model="heroPortfolio.image" accept=".webp" class="hidden" />
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["heroPortfolio.image"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </label>
                    </div>
                    <div class="">
                        <div class="flex flex-col gap-2 mb-4">
                            <label for="heroPortfolio.name" class="text-sm font-medium">Hero Profile Name</label>
                            <input type="text"
                                class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-bacancy-primary"
                                placeholder="Enter hero profile name"
                                wire:model="heroPortfolio.name"
                            ></input>
                        </div>
                        <div class="flex flex-col gap-2 mb-4">
                            <label for="heroPortfolio.title" class="text-sm font-medium">Hero Profile Title</label>
                            <input type="text"
                                class="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-bacancy-primary"
                                placeholder="Enter hero profile title"
                                wire:model="heroPortfolio.title"
                            ></input>
                        </div>
                        <div class="">
                            <label class="text-sm font-medium">Hero Profile Icons</label>
                            <div class="flex flex-wrap gap-2">
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $floatingIcons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $icon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="aspect-[1/1] flex items-center justify-center w-20 relative bg-white rounded border overflow-hidden">
                                        <!--[if BLOCK]><![endif]--><?php if(isset($icon) && is_object($icon)): ?>
                                            <img src="<?php echo e($icon->temporaryUrl()); ?>" class="w-full object-contain" alt="icon" />
                                        <?php elseif($icon && !is_object($icon)): ?>
                                            <img src="<?php echo e(asset($icon)); ?>" class="w-full object-contain" alt="icon" />
                                        <?php else: ?>
                                            <div class="w-full h-full flex items-center justify-center border shadow-md text-sm text-white p-2 bg-gray-400">
                                                Upload Logo
                                            </div>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                                        <!-- 👇 Fixed binding here -->
                                        <input type="file" wire:model="floatingIcons.<?php echo e($key); ?>" wire:change="changefloatingIcon(<?php echo e($key); ?>)" accept=".webp" class="hidden" />

                                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ["floatingIcons.$key"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-red-500 text-xs absolute -bottom-5 left-0"><?php echo e($message); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                </div>
            </fieldset>
            <!-- Save Button -->
            <div class="absolute -top-10 px-2 end-0 flex justify-center">
                <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 cursor-pointer bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                    <span wire:loading wire:target="save">saving...</span>
                    <span wire:loading.remove wire:target="save">Save</span>
                </button>
            </div>
        </form>
    </fieldset>   
    <?php else: ?>
    <div class="md:h-screen">
        <div class="relative md:flex grid flex-1 gap-4 md:space-y-0 space-y-32 py-6 px-4 py-2 sm:px-6 lg:px-8 overflow-hidden mx-auto h-full">
            <div class="md:w-[60%] flex flex-col justify-around md:items-start items-center h-full relative">
                <div class="relative z-20 flex flex-col items-center gap-10 justify-center md:items-start h-full md:items-start">
                    <div class="flex flex-col md:text-left text-center gap-8">
                        <p class="md:text-xl 2xl:text-3xl text-xl"><?php echo $hero_subtitle; ?></p>
                        <h1 class="md:text-4xl lg:text-[50px] 2xl:text-[70px] text-3xl font-extrabold vast-shadow-bold"><?php echo $hero_title; ?></h1>
                        <div class="md:text-xl lg:text-[30px] 2xl:text-[40px] text-xl font-extrabold vast-shadow-bold"><?php echo $hero_shorttext; ?></div>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => 'book-a-call']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-a-call']); ?>
                        <?php if (isset($component)) { $__componentOriginal223d1ffece829ef6a495ad9046836fbc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal223d1ffece829ef6a495ad9046836fbc = $attributes; } ?>
<?php $component = App\View\Components\SiliconValley\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('silicon-valley.action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiliconValley\ActionButton::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hover:bg-sv-secondary/50 text-lg md:text-xl 2xl:text-3xl','x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'Hire Now\')','title' => ''.e($buttonText).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $attributes = $__attributesOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $component = $__componentOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__componentOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="md:w-[40%] w-full flex justify-center items-center relative">
                <div class="aspect-[1.3/2] rounded-xl p-1 lg:h-3/4 md:h-2/3 w-1/2 md:w-auto border-2 border-white relative">
                    <img loading="lazy" class="aspect-[1.3/2] object-cover rounded-xl h-full absolute top-2 start-2" src="<?php echo e(asset($heroPortfolio['image'])); ?>"/>
                    <div class="w-full h-full relative">
                        <div class="bg-white shadow-md aspect-[1.5/1] 2xl:h-18 h-12 md:h-16 flex justify-center  animate-[bounce_2.7s_ease-in-out_infinite] max-w-auto p-2 rounded absolute top-5 -start-10">
                            <img loading="lazy" class="h-full object-container" src="<?php echo e(asset($floatingIcons[0])); ?>" alt="node.js">
                        </div>
                        <div class="bg-white shadow-md aspect-[1.5/1] 2xl:h-18 h-12 md:h-16 flex justify-center  animate-[bounce_2.3s_ease-in-out_infinite] max-w-auto p-2 rounded absolute -top-5 -end-10">
                            <img loading="lazy" class="h-full object-container" src="<?php echo e(asset($floatingIcons[1])); ?>" alt="python">
                        </div>
                        <div class="bg-white shadow-md aspect-[1.5/1] 2xl:h-18 h-12 md:h-16 flex justify-center animate-[bounce_3s_ease-in-out_infinite] max-w-auto p-2 rounded absolute bottom-5 -start-10">
                            <img loading="lazy" class="h-full object-container" src="<?php echo e(asset($floatingIcons[2])); ?>" alt="firebase">
                        </div>
                        <div class="bg-white shadow-md aspect-[1.5/1] 2xl:h-18 h-12 md:h-16 flex justify-center animate-[bounce_2s_ease-in-out_infinite] max-w-auto p-2 rounded absolute bottom-20 -end-10">
                            <img loading="lazy" class="h-full object-container" src="<?php echo e(asset($floatingIcons[3])); ?>" alt="react">
                        </div>
                    </div>
                    <div class="border-e border-b pb-1 pe-1 absolute md:-bottom-6 -bottom-10 md:-end-20 -end-20 rounded-lg border-white">
                        <div class="bg-sv-primary p-3 py-1 rounded">  
                            <p class="text-center md:text-md 2xl:text-lg text-xs m-2"><?php echo e($heroPortfolio['name']); ?></p>
                            <hr class="border-gray-200">
                            <div class="bg-gray-200/20 md:text-sm 2xl:text-lg text-xs p-1 px-2 rounded w-max m-2"><?php echo e($heroPortfolio['title']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\serverfile\resources\views/livewire/silicon-valley/hero-section.blade.php ENDPATH**/ ?>