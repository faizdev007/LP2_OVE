<div class="py-12 bg-sv-secondary px-2">
    
    <div class="max-w-5xl rounded-lg py-20 md:px-10 px-2 shadow-md mx-auto text-center text-white bg-sv-primary flex flex-col gap-10">
        <h2 class="text-xl md:text-4xl 2xl:text-5xl font-bold">Great Products Start With Great Teams.</h2>
        <p class="text-lg md:text-2xl 2xl:text-3xl">Hire your next developer today.</p>
        <?php if (isset($component)) { $__componentOriginal1db8c57e729d67f7d4103875cf3230cb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'e60dd9d2c3a62d619c9acb38f20d5aa5::modal.trigger','data' => ['name' => 'book-a-call']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('flux::modal.trigger'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'book-a-call']); ?>
            <?php if (isset($component)) { $__componentOriginal223d1ffece829ef6a495ad9046836fbc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal223d1ffece829ef6a495ad9046836fbc = $attributes; } ?>
<?php $component = App\View\Components\SiliconValley\ActionButton::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('silicon-valley.action-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SiliconValley\ActionButton::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'hover:bg-sv-secondary/50 text-lg md:text-xl 2xl:text-3xl','x-data' => '','x-on:click.prevent' => '$dispatch(\'open-modal\', \'Hire Now\')','title' => 'Talk to Us']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $attributes = $__attributesOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__attributesOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal223d1ffece829ef6a495ad9046836fbc)): ?>
<?php $component = $__componentOriginal223d1ffece829ef6a495ad9046836fbc; ?>
<?php unset($__componentOriginal223d1ffece829ef6a495ad9046836fbc); ?>
<?php endif; ?>
         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $attributes = $__attributesOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__attributesOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb)): ?>
<?php $component = $__componentOriginal1db8c57e729d67f7d4103875cf3230cb; ?>
<?php unset($__componentOriginal1db8c57e729d67f7d4103875cf3230cb); ?>
<?php endif; ?>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\serverfile\resources\views/livewire/silicon-valley/ctn.blade.php ENDPATH**/ ?>