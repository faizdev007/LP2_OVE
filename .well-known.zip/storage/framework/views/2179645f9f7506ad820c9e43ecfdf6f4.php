<div class="my-12 scroll-mt-20" section="companies-logo">
    
    <!--[if BLOCK]><![endif]--><?php if(Route::currentRouteName() === 'create_lp_content' || Route::currentRouteName() === 'livewire.update' && auth()->check()): ?>
        <div class="py-4">
            <fieldset class="container relative max-w-6xl p-4 rounded mx-auto border-2 border-bacancy-primary">
                <?php if (isset($component)) { $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.messagestatus','data' => ['successMessage' => $successMessage,'errorMessage' => $errorMessage]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('messagestatus'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['successMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($successMessage),'errorMessage' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errorMessage)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $attributes = $__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__attributesOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16)): ?>
<?php $component = $__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16; ?>
<?php unset($__componentOriginal4d5bb2a2f3a010b0db21321a1d9dfd16); ?>
<?php endif; ?>
                <legend class="text-xl font-bold text-gray-900  markque px-2">Companies Logo</legend>
                <p class="text-gray-600">Upload and Remove Companies Logo for Current Landing Page.</p>
                
                <div x-data="{
                        previews: <?php if ((object) ('existing_logos') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('existing_logos'->value()); ?>')<?php echo e('existing_logos'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('existing_logos'); ?>')<?php endif; ?>,
                        removed: <?php if ((object) ('removed_logos') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('removed_logos'->value()); ?>')<?php echo e('removed_logos'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('removed_logos'); ?>')<?php endif; ?>
                    }">
                    <form wire:submit.prevent="save" class="space-y-4">
                        <!-- Upload New Logos -->
                        <input type="file" wire:model="company_logos" multiple accept=".webp" class="block mb-2 inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg shadow hover:bg-blue-700 cursor-pointer transition" />
                        <div class="mt-2 text-sm text-gray-500">
                            Only <strong>.webp</strong> files are allowed. You can select multiple.
                        </div>
                        <!-- Preview Uploaded Logos -->
                        <div class="flex flex-wrap gap-3">
                            <template x-for="(logo, index) in previews" :key="logo">
                                <div class="relative w-24 border rounded">
                                    <img :src="'<?php echo e(url('')); ?>' + logo" alt="" class="w-full h-full object-cover rounded">
                                    <button type="button"
                                        @click="console.log(previews); removed.push(logo); previews.splice(index, 1)"
                                        class="absolute top-0 right-0 bg-red-600 text-white text-xs px-1 rounded">
                                        ✕
                                    </button>
                                </div>
                            </template>
                        </div>
                        <!-- Save Button -->
                        <div class="absolute -top-10 px-2 end-0 flex justify-center">
                            <button type="submit" wire:loading.attr="disabled" class="px-6 py-3 cursor-pointer bg-bacancy-primary text-white rounded-full hover:bg-blue-600 transition">
                                <span wire:loading wire:target="save">saving...</span>
                                <span wire:loading.remove wire:target="save">Save</span>
                            </button>
                        </div>
                    </form>
                </div>

            </fieldset>
        </div>
    <?php else: ?>
    <?php
        $companyLogos = $existing_logos;
    ?>
    <div class="relative flex-1 gap-4 overflow-hidden px-4 sm:px-6 lg:px-8 mx-auto ">
        <div class="logo-slider flex w-max md:space-x-8 space-x-4">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($logo)); ?>" class="h-16 p-2 border border-black shadow w-auto border rounded" alt="Logo <?php echo e($index + 1); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($logo)); ?>" class="h-16 p-2 border border-black shadow w-auto border rounded" alt="Logo <?php echo e($index + 1); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($logo)); ?>" class="h-16 p-2 border border-black shadow w-auto border rounded" alt="Logo <?php echo e($index + 1); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $companyLogos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $logo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e(asset($logo)); ?>" class="h-16 p-2 border border-black shadow w-auto border rounded" alt="Logo <?php echo e($index + 1); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\xampp\htdocs\serverfile\resources\views/livewire/bacancypage/companies-logo.blade.php ENDPATH**/ ?>